/*
Copyrights - Sameer Khandekar
Creative Commons Attribution-NonCommercial 4.0 International License.
*/
#ifndef _HTTPVERBS_h
#define _HTTPVERBS_h

// http verbs

#define	VERB_GET String("GET")
#define VERB_PUT String("PUT")
#define VERB_POST String("POST")
#define VERB_DELETE String("DELETE")

#endif